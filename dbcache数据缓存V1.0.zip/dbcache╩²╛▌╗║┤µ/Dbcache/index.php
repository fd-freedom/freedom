<?php
/**
*@version 1.0 Dbchache 数据缓存
*/
 header("content-type:text/html;charset=utf8");
 include_once("bin/kernel.php");

?>